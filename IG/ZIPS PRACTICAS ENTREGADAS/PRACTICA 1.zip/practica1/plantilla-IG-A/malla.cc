#include "aux.h"
#include "ply_reader.h"
#include "malla.h"

using namespace std;

// *****************************************************************************
//
// Clase ObjMallaIndexada
//
// *****************************************************************************

//Método para calcular caras pares e impares y las devuelve en un vector
std::vector<Tupla3i> ObjMallaIndexada::getTriangulosParImpar(bool modo){
   std::vector<Tupla3i> triangulos_paridad;

   unsigned int i;

   //Si modo es 0 es par si modo es 1 es impar
   if(modo)
    i=0;
   else
    i=1;

   for( ;i<triangulos.size(); i+=2){
      triangulos_paridad.push_back(triangulos.at(i));
   }

   return triangulos_paridad;
}

//Numero de vertices
int ObjMallaIndexada::getVertices(){
  return vertices.size();
}

//Numero de Triangulos
int ObjMallaIndexada::getTriangulos(){
  return triangulos.size();
}

//Crear VBOs
GLuint ObjMallaIndexada::CrearVBO( GLuint tipo_vbo, GLuint tamanio_bytes, GLvoid * puntero_ram )
{
  GLuint id_vbo ; // resultado: identificador de VBO
  glGenBuffers( 1, & id_vbo ); // crear nuevo VBO, obtener identificador (nunca 0)
  glBindBuffer( tipo_vbo, id_vbo ); // activar el VBO usando su identificador
  // esta instrucción hace la transferencia de datos desde RAM hacia GPU
  glBufferData( tipo_vbo, tamanio_bytes, puntero_ram, GL_STATIC_DRAW );
  glBindBuffer( tipo_vbo, 0 ); // desactivación del VBO (activar 0)
  return id_vbo ; // devolver el identificador resultado
}

// Visualización en modo inmediato con 'glDrawElements'

void ObjMallaIndexada::draw_ModoInmediato()
{
  // visualizar la malla usando glDrawElements,
  // completar (práctica 1)

  //Le dice a OpenGL especificandole un puntero a una tabla de vertices
  glEnableClientState( GL_VERTEX_ARRAY ); // habilitar ’vertex arrays’
  // especificar puntero a tabla de coords. de vértices (vertices.data() devuelve el puntero a la primera posicion del vector)
  glVertexPointer( 3, GL_FLOAT, 0, vertices.data() );
  // dibujar usando vértices indexados (tringulos.data() lo mismo que antes devuelve el puntero a la primera posicion del vector)
  glDrawElements( GL_TRIANGLES, 3*triangulos.size(), GL_UNSIGNED_INT, triangulos.data() ) ;
  glDisableClientState( GL_VERTEX_ARRAY ); //desabilita el uso de las coordenadas de vertices
}
// -----------------------------------------------------------------------------
// Visualización en modo diferido con 'glDrawElements' (usando VBOs)

void ObjMallaIndexada::draw_ModoDiferido()
{
   // (la primera vez, se deben crear los VBOs y guardar sus identificadores en el objeto)
   // completar (práctica 1)

   if(id_vbo_ver==0)
    id_vbo_ver = CrearVBO(GL_ARRAY_BUFFER, 3*vertices.size()*sizeof(float), vertices.data());

   if(id_vbo_tri==0)
    id_vbo_tri = CrearVBO(GL_ELEMENT_ARRAY_BUFFER, 3*triangulos.size()*sizeof(int), triangulos.data());

   // especificar localización y formato de la tabla de vértices, habilitar tabla
   glBindBuffer( GL_ARRAY_BUFFER, id_vbo_ver ); // activar VBO de vértices
   glVertexPointer( 3, GL_FLOAT, 0, 0 ); // especifica formato y offset (=0)
   glBindBuffer( GL_ARRAY_BUFFER, 0 ); // desactivar VBO de vértices.
   glEnableClientState( GL_VERTEX_ARRAY ); // habilitar tabla de vértices
   // visualizar triángulos con glDrawElements (puntero a tabla == 0)
   glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, id_vbo_tri );// activar VBO de triángulos
   glDrawElements( GL_TRIANGLES, 3*triangulos.size(), GL_UNSIGNED_INT, 0 ) ;
   glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 ); // desactivar VBO de triángulos
   // desactivar uso de array de vértices
   glDisableClientState( GL_VERTEX_ARRAY );
}

//Metodo que pinta en modo ajedrez el modelo en modo inmediato
void ObjMallaIndexada::draw_ModoInmediatoAjedrez(){
  std::vector<Tupla3i> triangulos_par = getTriangulosParImpar(0);
  std::vector<Tupla3i> triangulos_impar = getTriangulosParImpar(1);

  glShadeModel(GL_FLAT);
  glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
  glEnableClientState( GL_VERTEX_ARRAY );
  glVertexPointer( 3, GL_FLOAT, 0, &vertices.at(0) );
  glColor3f( 1.0, 0.0, 0.0 );
  glDrawElements( GL_TRIANGLES, triangulos_impar.size()*3 , GL_UNSIGNED_INT, &(triangulos_impar.at(0)));

  glColor3f( 0.0, 1.0, 0.0 );
  glDrawElements( GL_TRIANGLES, triangulos_par.size()*3 , GL_UNSIGNED_INT, &(triangulos_par.at(0)));
}

// -----------------------------------------------------------------------------
// Función de visualización de la malla,
// puede llamar a  draw_ModoInmediato o bien a draw_ModoDiferido

void ObjMallaIndexada::draw(int modo)
{
   // completar .....(práctica 1)
   switch(modo)
   {
      case 0:
        draw_ModoInmediato();
        break ;
      case 1:
        draw_ModoDiferido();
        break ;
      case 2:
        draw_ModoInmediatoAjedrez();
        break ;
      default:
        cout << "modo: el número de modo de dibujo actual (" << modo << ") es incorrecto." << endl ;
      break ;
    }
}
// -----------------------------------------------------------------------------
// Recalcula la tabla de normales de vértices (el contenido anterior se pierde)

void ObjMallaIndexada::calcular_normales()
{
   // completar .....(práctica 2)
}

// *****************************************************************************
//
// Clase Cubo (práctica 1)
//
// *****************************************************************************

Cubo::Cubo()
{

   // inicializar la tabla de vértices
   vertices =  {  { -0.5, -0.5, -0.5 }, // 0
                  { -0.5, -0.5, +0.5 }, // 1
                  { -0.5, +0.5, -0.5 }, // 2
                  { -0.5, +0.5, +0.5 }, // 3
                  { +0.5, -0.5, -0.5 }, // 4
                  { +0.5, -0.5, +0.5 }, // 5
                  { +0.5, +0.5, -0.5 }, // 6
                  { +0.5, +0.5, +0.5 }  // 7
               };

   // inicializar la tabla de caras o triángulos:
   // (es importante en cada cara ordenar los vértices en sentido contrario
   //  de las agujas del reloj, cuando esa cara se observa desde el exterior del cubo)

   triangulos = { { 0, 2, 4 }, { 4, 2, 6 },
                  { 1, 5, 3 }, { 3, 5, 7 },
                  { 1, 3, 0 }, { 0, 3, 2 },
                  { 5, 4, 7 }, { 7, 4, 6 },
                  { 1, 0, 5 }, { 5, 0, 4 },
                  { 3, 7, 2 }, { 2, 7, 6 }
                } ;
   /*triangulos = { { 1, 5, 7 }, { 1, 7, 3 },
                  { 5, 4, 6 }, { 5, 6, 7 },
                  { 4, 0, 2 }, { 4, 2, 6 },
                  { 0, 1, 3 }, { 0, 3, 2 },
                  { 3, 7, 6 }, { 3, 6, 2 },
                  { 0, 5, 4 }, { 1, 5, 0 }
                } ;*/

}

// *****************************************************************************
//
// Clase Tetraedro (práctica 1)
//
// *****************************************************************************

Tetraedro::Tetraedro()
{

   // inicializar la tabla de vértices
   vertices =  {  { 0, 0.5, 0 }, // 0
                  { 0.5, 0, -0.5 }, // 1
                  { 0, 0, 0.5 }, // 2
                  { -0.5, 0, -0.5 } // 3
               };

   // inicializar la tabla de caras o triángulos:
   // (es importante en cada cara ordenar los vértices en sentido contrario
   //  de las agujas del reloj, cuando esa cara se observa desde el exterior del cubo)

   triangulos = { { 1, 2, 3 }, { 1, 0, 2 },
                  { 2, 0, 3 }, { 3, 0, 1 }
                } ;
}

// *****************************************************************************
//
// Clase ObjPLY (práctica 2)
//
// *****************************************************************************

ObjPLY::ObjPLY( const std::string & nombre_archivo )
{
   // leer la lista de caras y vértices
   ply::read( nombre_archivo, vertices, triangulos );
}


// *****************************************************************************
//
// Clase ObjRevolucion (práctica 2)
//
// *****************************************************************************


// *****************************************************************************
// objeto de revolución obtenido a partir de un perfil (en un PLY)

ObjRevolucion::ObjRevolucion( const std::string & nombre_ply_perfil )
{
  // completar ......(práctica 2)

}
