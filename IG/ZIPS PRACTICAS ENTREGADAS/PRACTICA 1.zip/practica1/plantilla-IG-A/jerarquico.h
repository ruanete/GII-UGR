// #############################################################################
//
// Informática Gráfica (Grado Informática)
//
// Archivo: jerarquico.h
// -- declaraciones de clase para el objeto jerárquico de la práctica 3
//
// #############################################################################

#ifndef JERARQUICO_H_INCLUDED
#define JERARQUICO_H_INCLUDED

#include "malla.h"

class ObjJerarquico
{
   private:
      // elementos privados.....
   public:
   ObjJerarquico();
   void draw() ;
} ;

#endif
