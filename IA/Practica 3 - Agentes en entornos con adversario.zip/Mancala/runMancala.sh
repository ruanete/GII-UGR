java -jar Mancala.jar

