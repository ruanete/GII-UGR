/*
 * ruaneteBOT.cpp
 *
 *  Created on: 15 ene. 2018
 *      Author: manupc
 */

#include "ruaneteBOT.h"

#include <string>
#include <cstdlib>
#include <iostream>
#include <list>
#include <limits>
using namespace std;

ruaneteBOT::ruaneteBOT() {
	// Inicializar las variables necesarias para ejecutar la partida

}

ruaneteBOT::~ruaneteBOT() {
	// Liberar los recursos reservados (memoria, ficheros, etc.)
}

void ruaneteBOT::initialize() {
	// Inicializar el bot antes de jugar una partida
}

string ruaneteBOT::getName() {
	return "ruaneteBOT"; // Sustituir por el nombre del bot
}

/*	Método que devuelve si un nodo tiene turno gratis que esto es cuando el turno del nodo hijo es igual al del nodo padre*/
bool ruaneteBOT::turnoGratis(nodo n){
	bool comprueba=false;
	if(n.padre.getCurrentPlayer()==n.state.getCurrentPlayer())
		comprueba=true;
	return comprueba;
}

/*Método que comprueba si realizando el movimiento para ir al hijo se produce un robo o no de semillas*/
bool ruaneteBOT::robaSemillas(nodo n){
	Player jugador = this->getPlayer();
	Player oponente;
	bool comprueba = false;
	if(jugador==Player::J1)
		oponente = Player::J2;
	else
		oponente = Player::J1;

	Position p = Position(n.move);


	int semillas = n.padre.getSeedsAt(jugador, p);

	if(semillas > 0 && semillas<6-Position(p) && (int)n.padre.getSeedsAt(jugador, Position(Position(p)-semillas))==0 && (int)n.padre.getSeedsAt(oponente, Position(Position(p)-semillas))>0){
		comprueba=true;
	}
	return comprueba;
}

/*Método que devuelve el valor en función de la heuristica usada del nodo que queremos evaluar.*/
int ruaneteBOT::funcionEvaluacion(nodo n){
	Player jugador = this->getPlayer();
	int evaluacion=0;

	if(jugador==Player::J1){
		evaluacion = n.state.getScore(jugador) - n.state.getScore(Player::J2);
		evaluacion += (25 - n.state.getScore(Player::J2));
		if(turnoGratis(n))
			evaluacion +=1;

		if(robaSemillas(n))
			evaluacion +=1;

		return evaluacion;
	}else{
		evaluacion = n.state.getScore(jugador) - n.state.getScore(Player::J1);
		evaluacion += (25 - n.state.getScore(Player::J1));
		if(turnoGratis(n))
			evaluacion +=1;

		if(robaSemillas(n))
				evaluacion +=1;

		return evaluacion;
	}
}

/*Método que genera un nodo sucesor del nodo n en función del movimiento i*/
nodo ruaneteBOT::generaSucesor(const nodo& n, int i){
	nodo hijo;

	hijo.padre = n.state;
	hijo.state = n.state.simulateMove(Move (i));
	hijo.move = Move (i);
	hijo.valor = funcionEvaluacion(hijo);

	return hijo;
}

/*Implementación del algoritmo de busqueca minimax alfa beta, el cual tiene dos método para maximizar y para minimizar*/
nodo ruaneteBOT::MINIMAX_A_B(nodo &n, int profundidad, int Alfa, int Beta, bool maximizarNodo){
	if(profundidad == 0 || n.state.isFinalState()){
		return n;
	}

	if(maximizarNodo)
		return MAXIMIZADOR_A_B(n, profundidad, Alfa, Beta);
	else
		return MINIMIZADOR_A_B(n, profundidad, Alfa, Beta);
}

/*Método máximizador del algoritmo de busqueda usado, es el que elige el maximo de los nodos hijos*/
nodo ruaneteBOT::MAXIMIZADOR_A_B(nodo n,int profundidad, int& Alfa, int& Beta){
	int mejorValor=numeric_limits<int>::min();
	nodo mejorNodo;
	nodo minimax;
	int valor;
	nodo hijo;

	for(int i=1;i<=6;i++){
		hijo = generaSucesor(n,i);

		if(hijo.state.getCurrentPlayer() == hijo.padre.getCurrentPlayer()){
			minimax = MINIMAX_A_B(hijo, profundidad-1, Alfa, Beta, true);
			valor = minimax.valor;
		}else{
			minimax = MINIMAX_A_B(hijo, profundidad-1, Alfa, Beta, false);
			valor = minimax.valor;
		}

		if(valor > mejorValor){
			mejorValor = valor;
			mejorNodo = minimax;
			mejorNodo.move = hijo.move;
		}

		Alfa = max(Alfa, mejorValor);

		if (Beta <= Alfa) {
    	break;
    }
	}

	return mejorNodo;
}

/*Método minimizador del algoritmo de busqueda usado, es el que elige el mínimo de los nodos hijos*/
nodo ruaneteBOT::MINIMIZADOR_A_B(nodo n,int profundidad, int& Alfa, int& Beta){
	int mejorValor=numeric_limits<int>::max();
	nodo mejorNodo;
	nodo minimax;
	nodo hijo;
	int valor;

	for(int i=1;i<=6;i++){
		hijo = generaSucesor(n,i);

		if(hijo.state.getCurrentPlayer() == hijo.padre.getCurrentPlayer()){
			minimax = MINIMAX_A_B(hijo, profundidad-1, Alfa, Beta, false);
			valor = minimax.valor;
		}else{
			minimax = MINIMAX_A_B(hijo, profundidad-1, Alfa, Beta, true);
			valor = minimax.valor;
		}

		if(valor < mejorValor){
			mejorValor = valor;
			mejorNodo = minimax;
			mejorNodo.move = hijo.move;
		}

		Beta = min(Beta,mejorValor);

		if (Beta <= Alfa) {
    	break;
    }
	}
	return mejorNodo;
}

Move ruaneteBOT::nextMove(const vector<Move> &adversary, const GameState &state) {
	Player turno= this->getPlayer();
	long timeout= this->getTimeOut();
	Move movimiento= M_NONE;

	// Implementar aquí la selección de la acción a realizar

	// OJO: Recordatorio. NO USAR cin NI cout.
	// Para salidas por consola (debug) utilizar cerr. Ejemplo:
	// cerr<< "Lo que quiero mostrar"<<endl;


	// OJO: Recordatorio. El nombre del bot y de la clase deben coincidir.
	// En caso contrario, el bot no podrá participar en la competición.
	// Se deberá sustituir el nombre ruaneteBOT como nombre de la clase por otro
	// seleccionado por el alumno. Se deberá actualizar también el nombre
	// devuelto por el método getName() acordemente.

	int profundidad = 12;

	nodo inicio;
	inicio.state = state;
	inicio.padre = state;
	inicio.valor = 0;
	inicio.move = M_NONE;
	nodo final;

	return MINIMAX_A_B(inicio, profundidad, numeric_limits<int>::min(), numeric_limits<int>::max(), true).move;
}
