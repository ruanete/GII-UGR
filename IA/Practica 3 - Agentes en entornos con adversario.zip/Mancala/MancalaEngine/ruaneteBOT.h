/*
 * ruaneteBOT.h
 *
 *  Created on: 15 ene. 2018
 *      Author: manupc
 */

#include "Bot.h"
#include <list>
#include <limits>

#ifndef MANUPCBOT_H_
#define MANUPCBOT_H_

struct nodo{
	GameState state;
	GameState padre;
	Move move;
	int valor;
};

class ruaneteBOT:Bot {
private:

public:
	ruaneteBOT();
	~ruaneteBOT();


	void initialize();
	string getName();
	Move nextMove(const vector<Move> &adversary, const GameState &state);
	nodo MINIMAX_A_B(nodo &n, int profundidad, int Alfa, int Beta, bool maximizarNodo);
	nodo MAXIMIZADOR_A_B(nodo n,int profundidad, int& Alfa, int& Beta);
	nodo MINIMIZADOR_A_B(nodo n,int profundidad, int& Alfa, int& Beta);
	int funcionEvaluacion(nodo n);
	nodo generaSucesor(const nodo& n, int i);
	bool turnoGratis(nodo n);
	bool robaSemillas(nodo n);
};

#endif /* MANUPCBOT_H_ */
