#!/bin/csh
@ inicio = 100
@ fin = 200000
@ incremento = 100
@ i = $inicio
echo > tiempos.dat
while ( $i <= $fin )
 echo Ejecución tam = $i
 echo `./usoabb $i 10000` >> tiempos.dat
 @ i += $incremento
end
