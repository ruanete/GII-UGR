#include "abb.h"
#include <string>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <chrono>// Recursos para medir tiempos

using namespace std;
using namespace std::chrono;

void Seleccion (int  *v, int n)
{
  int min,i,j,aux;
  for (i=0; i<n-1; i++){
    min=i;
    for(j=i+1; j<n; j++)
      if(v[min] > v[j])
        min=j;

    aux=v[min];
    v[min]=v[i];
    v[i]=aux ;
  }
}

void SeleccionReves (int  *v, int n)
{
  int min,i,j,aux;
  for (i=0; i<n-1; i++){
    min=i;
    for(j=i+1; j<n; j++)
      if(v[min] < v[j])
        min=j;

    aux=v[min];
    v[min]=v[i];
    v[i]=aux ;
  }
}

void ListarAbb(ABB<int> &ab_bus, int *v){
  ABB<int>::nodo n;
  int i=0;

  for (n=ab_bus.begin();n!=ab_bus.end();++n){
    v[i] = *n;
    i++;
  }
}

void sintaxis(){
  cerr << "Sintaxis:" << endl;
  cerr << "  TAM: Tamaño del vector (>0)" << endl;
  cerr << "  VMAX: Valor máximo (>0)" << endl;
  cerr << "Se genera un vector de tamaño TAM con elementos aleatorios en [0,VMAX[" << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char * argv[]){
  if (argc!=3)
   sintaxis();
  int tam=atoi(argv[1]);
  int vmax=atoi(argv[2]);
  if (tam<=0 || vmax<=0)
   sintaxis();

  int *v=new int[tam];
  int *v_final=new int[tam];

  //INSERTO VECTOR ORDENADO PARA EL PEOR CASO
  /*for (int i=0; i<tam; i++)
    v[i] = i;

  high_resolution_clock::time_point start, end;
  duration<double> tiempo_transcurrido;
  ABB<int>ab_bus;

  start = high_resolution_clock::now();

  for (int i=0;i<tam;i++)
    ab_bus.Insertar(v[i]);
  ListarAbb(ab_bus,v_final);
  end = high_resolution_clock::now();
  */

  //INSERTO VECTOR ALETORIO PARA EL MEJOR Y PROMEDIO CASO

  srand(time(0));
  for (int i=0; i<tam; i++)
   v[i] = rand() % vmax;

  high_resolution_clock::time_point start, end;
  duration<double> tiempo_transcurrido;
  ABB<int>ab_bus;

  start = high_resolution_clock::now();

  for (int i=0;i<tam;i++)
    ab_bus.Insertar(v[i]);

  ListarAbb(ab_bus,v_final);

  end = high_resolution_clock::now();

  tiempo_transcurrido  = duration_cast<duration<double> >(end - start);

	cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

  delete [] v;
  delete [] v_final;
}
