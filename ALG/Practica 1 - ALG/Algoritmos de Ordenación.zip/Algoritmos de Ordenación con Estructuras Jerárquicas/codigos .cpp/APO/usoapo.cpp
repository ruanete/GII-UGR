#include "apo.h"
#include <chrono>// Recursos para medir tiempos

using namespace std;
using namespace std::chrono;

void sintaxis(){
  cerr << "Sintaxis:" << endl;
  cerr << "  TAM: Tamaño del vector (>0)" << endl;
  cerr << "  VMAX: Valor máximo (>0)" << endl;
  cerr << "Se genera un vector de tamaño TAM con elementos aleatorios en [0,VMAX[" << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char * argv[]){
	APO<int>ap_int;
	if (argc!=3)
		sintaxis();
	int tam=atoi(argv[1]);
	int vmax=atoi(argv[2]);
	if (tam<=0 || vmax<=0)
		sintaxis();

	high_resolution_clock::time_point start, end;
	duration<double> tiempo_transcurrido;

	start = high_resolution_clock::now();

	srand(time(0));
  for (int i=0; i<tam; i++)
    ap_int.insertar(rand() % vmax);

	for (int i=0; i<tam; i++)
		ap_int.borrar_minimo();

	end = high_resolution_clock::now();

  tiempo_transcurrido  = duration_cast<duration<double> >(end - start);

	cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

}
