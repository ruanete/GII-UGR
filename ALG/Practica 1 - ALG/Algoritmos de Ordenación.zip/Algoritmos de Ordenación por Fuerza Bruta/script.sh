#!/bin/csh
@ inicio = 1
@ fin = 9
@ incremento = 1
@ i = $inicio
echo > tiempos.dat
while ( $i <= $fin )
 echo Ejecución tam = $i
 echo `./pruebapermutacionMEJORCASO $i 9` >> tiempos.dat
 @ i += $incremento
end
