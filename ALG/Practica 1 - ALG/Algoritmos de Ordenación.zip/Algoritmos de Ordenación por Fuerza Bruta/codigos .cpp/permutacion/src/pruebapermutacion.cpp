#include <iostream>
#include "permutacion.h"
#include <string>
#include <cstdlib>  // Para generación de números pseudoaleatorios
#include <chrono>// Recursos para medir tiempos
using namespace std;
using namespace std::chrono;

template <class T>
ostream & operator<<(ostream &os, const vector<T> & d){
   for (unsigned int i=0;i<d.size();i++)
      os<<d[i]<<" ";
   os<<endl;
   return os;
}

void MuestraPermutaciones(const Permutacion & P){
  Permutacion::const_iterator it;
  int cnt=1;
  for (it=P.begin();it!=P.end();++it,++cnt)
      cout<<cnt<<"->"<<*it<<endl;

}

void ImprimeCadena(const int *v,const Permutacion &P){
  const vector<unsigned int> s= (*(P.begin()));

  for (unsigned int i=0;i<s.size();i++)
     cout<<v[s[i]-1];
  cout<<endl;
}

bool CompruebaOrdenado(const int *v, const int n){
  bool comprueba=true;
  for(int i=0;i<n-1;i++){
    if(v[i]>v[i+1]){
      comprueba=false;
      break;
    }
  }
  return comprueba;
}

void ModificaVector(int *v, int *v_final, const int *v_base, const Permutacion &P){
  const vector<unsigned int> s= (*(P.begin()));

  /*for (unsigned int i=0;i<s.size();i++)
     cout<<v[s[i]-1];

  cout << "-";*/
  for (unsigned int i=0;i<s.size();i++){
     v_final[i] = v_base[v[s[i]-1]];
     //cout << v_final[i];
   }
   //cout << endl;
}

void sintaxis()
{
  cerr << "Sintaxis:" << endl;
  cerr << "  TAM: Tamaño del vector (>0)" << endl;
  cerr << "  VMAX: Valor máximo (>0)" << endl;
  cerr << "Se genera un vector de tamaño TAM con elementos aleatorios en [0,VMAX[" << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char * argv[]){
  if (argc!=3)
   sintaxis();
  int tam=atoi(argv[1]);
  int vmax=atoi(argv[2]);
  if (tam<=0 || vmax<=0)
   sintaxis();

  //Leemos una cadena y generamos todas sus permutaciones
  int *v = new int[tam];
  int *v_base = new int[tam];
  int *v_final = new int[tam];

  //Creo un vector con las posibles permutaciones de los indices del vector es decir si tam=5 permutaciones empiezan en 01234 y terminan en 43210
  //cout << "Vector de permutaciones: ";
  for (int i=0; i<tam; i++){
   v[i] = i;
   //cout << v[i];
  }

  //cout << endl;

  //Creo un vector con los valores que vamos a permutar, para ello los meto en un vector base que no modificaremos y la permutacion hace referencia al indice del vector de base que será incluido en v_final
  //PEOR CASO VECTOR JUSTO AL REVES
  //cout << "Vector a permutar: ";
  /*int j=0;
  for (int i=tam-1; i>=0; i--){
    v_base[j] = i;
    //cout << v_base[j];
    j++;
  }*/

  //MEJOR CASO VECTOR ORDENADO, en el mejor de los casos directamente compruebo si esta ordenado, pues la primera permutación ya va a sacar un vector ordenado solo tendria que comprobarlo
  //cout << "Vector a permutar: ";
  for (int i=0; i<tam; i++){
    v_base[i] = i;
    v_final[i] = i;
    //cout << v_base[i];
  }

  //cout << endl << endl;

  high_resolution_clock::time_point start, end;
  duration<double> tiempo_transcurrido, sumatorio;

  Permutacion Otra(tam,-1);
  ModificaVector(v,v_final,v_base,Otra);

  start = high_resolution_clock::now();

  CompruebaOrdenado(v_final,tam);
  /*do{
    ModificaVector(v,v_final,v_base,Otra);
    //cout << endl;
  }while(Otra.GeneraSiguiente() && CompruebaOrdenado(v_final,tam)==false);*/

  end = high_resolution_clock::now();
  tiempo_transcurrido = duration_cast<duration<double> >(end - start);
  sumatorio=sumatorio+tiempo_transcurrido;

  }
  sumatorio=sumatorio/30;
  tiempo_transcurrido=sumatorio;

  tiempo_transcurrido = duration_cast<duration<double> >(end - start);

  cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

  delete [] v;
  delete [] v_base;
  delete [] v_final;

}
