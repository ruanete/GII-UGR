#include <iostream>
#include <cstdlib>  // Para generación de números pseudoaleatorios
#include <chrono>// Recursos para medir tiempos
using namespace std;
using namespace std::chrono;

int Insercion(int *v, int n)
{
  for (int i=1; i<n; i++){
    int temp = v[i];
    int j = i - 1;
    while ( (v[j] > temp) && (j >= 0) ){
      v[j+1] = v[j];
      j--;
    }

    v[j+1] = temp;
  }
}

int InsercionReves(int *v, int n)
{
  for (int i=1; i<n; i++){
    int temp = v[i];
    int j = i - 1;
    while ( (v[j] < temp) && (j >= 0) ){
      v[j+1] = v[j];
      j--;
    }

    v[j+1] = temp;
  }
}

void sintaxis()
{
  cerr << "Sintaxis:" << endl;
  cerr << "  TAM: Tamaño del vector (>0)" << endl;
  cerr << "  VMAX: Valor máximo (>0)" << endl;
  cerr << "Se genera un vector de tamaño TAM con elementos aleatorios en [0,VMAX[" << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char * argv[])
{
 if (argc!=3)
  sintaxis();
 int tam=atoi(argv[1]);
 int vmax=atoi(argv[2]);
 if (tam<=0 || vmax<=0)
  sintaxis();

  //PRIMERA PARTE ES MEJOR Y PEOR CASO
 /*int *v=new int[tam];
 srand(time(0));
 for (int i=0; i<tam; i++)
  v[i] = rand() % vmax;

 high_resolution_clock::time_point start, end;
 duration<double> tiempo_transcurrido;

 //Insercion(v,tam); //EN EL MEJOR DE LOS CASOS PRIMERO ORDENAMOS Y LUEGO MEDIMOS
 //InsercionReves(v,tam); //EN EL PEOR DE LOS CASOS PRIMERO ORDENAMOS EL VECTOR AL REVES DE MAYOR A MENOR Y CALCULAMOS TIEMPO PARA ORDENARLO DE MENOR A MAYOR

 start = high_resolution_clock::now();
 Insercion(v,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido  = duration_cast<duration<double> >(end - start);

 cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

 delete [] v;*/

 //CASO PROMEDIO
 
 int *v1=new int[tam];
 int *v2=new int[tam];
 int *v3=new int[tam];

 srand(time(0));
 for (int i=0; i<tam; i++){
  v1[i] = rand() % vmax;
  v2[i] = rand() % vmax;
  v3[i] = rand() % vmax;
 }

 high_resolution_clock::time_point start, end;
 duration<double> tiempo_transcurrido;

 start = high_resolution_clock::now();
 Insercion(v1,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = duration_cast<duration<double> >(end - start);

 start = high_resolution_clock::now();
 Insercion(v2,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = tiempo_transcurrido + duration_cast<duration<double> >(end - start);

 start = high_resolution_clock::now();
 Insercion(v3,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = tiempo_transcurrido + duration_cast<duration<double> >(end - start);
 tiempo_transcurrido = tiempo_transcurrido / 3;

 cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

 delete [] v1;
 delete [] v2;
 delete [] v3;
}
