#include <iostream>
#include <cstdlib>  // Para generación de números pseudoaleatorios
#include <chrono>// Recursos para medir tiempos
using namespace std;
using namespace std::chrono;

void Seleccion (int  *v, int n)
{
  int min,i,j,aux;
  for (i=0; i<n-1; i++){
    min=i;
    for(j=i+1; j<n; j++)
      if(v[min] > v[j])
        min=j;

    aux=v[min];
    v[min]=v[i];
    v[i]=aux ;
  }
}

void SeleccionReves (int  *v, int n)
{
  int min,i,j,aux;
  for (i=0; i<n-1; i++){
    min=i;
    for(j=i+1; j<n; j++)
      if(v[min] < v[j])
        min=j;

    aux=v[min];
    v[min]=v[i];
    v[i]=aux ;
  }
}

void sintaxis()
{
  cerr << "Sintaxis:" << endl;
  cerr << "  TAM: Tamaño del vector (>0)" << endl;
  cerr << "  VMAX: Valor máximo (>0)" << endl;
  cerr << "Se genera un vector de tamaño TAM con elementos aleatorios en [0,VMAX[" << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char * argv[])
{
 if (argc!=3)
  sintaxis();
 int tam=atoi(argv[1]);
 int vmax=atoi(argv[2]);
 if (tam<=0 || vmax<=0)
  sintaxis();

//MEJOR Y PEOR CASO

 int *v=new int[tam];
 srand(time(0));
 for (int i=0; i<tam; i++)
  v[i] = rand() % vmax;

 high_resolution_clock::time_point start, end;
 duration<double> tiempo_transcurrido;

 //Seleccion(v,tam); //EN EL MEJOR DE LOS CASOS PRIMERO ORDENAMOS Y LUEGO MEDIMOS
 SeleccionReves(v,tam); //EN EL PEOR DE LOS CASOS PRIMERO ORDENAMOS EL VECTOR AL REVES DE MAYOR A MENOR Y CALCULAMOS TIEMPO PARA ORDENARLO DE MENOR A MAYOR

 start = high_resolution_clock::now();
 Seleccion(v,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido  = duration_cast<duration<double> >(end - start);

 cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

 delete [] v;

 //CASO PROMEDIO
/*
 int *v1=new int[tam];
 int *v2=new int[tam];
 int *v3=new int[tam];

 srand(time(0));
 for (int i=0; i<tam; i++){
  v1[i] = rand() % vmax;
  v2[i] = rand() % vmax;
  v3[i] = rand() % vmax;
 }

 high_resolution_clock::time_point start, end;
 duration<double> tiempo_transcurrido;

 start = high_resolution_clock::now();
 Seleccion(v1,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = duration_cast<duration<double> >(end - start);

 start = high_resolution_clock::now();
 Seleccion(v2,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = tiempo_transcurrido + duration_cast<duration<double> >(end - start);

 start = high_resolution_clock::now();
 Seleccion(v3,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = tiempo_transcurrido + duration_cast<duration<double> >(end - start);
 tiempo_transcurrido = tiempo_transcurrido / 3;

 cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

 delete [] v1;
 delete [] v2;
 delete [] v3;*/

}
