#include <iostream>
#include <cstdlib>  // Para generación de números pseudoaleatorios
#include <chrono>// Recursos para medir tiempos
using namespace std;
using namespace std::chrono;

void Burbuja (int  *v, int n)
{
  int aux;
  for(int i=1;i<n;i++){
    for(int j=0;j<n-i;j++){
      if(v[j]>v[j+1]){
        aux=v[j+1];
        v[j+1]=v[j];
        v[j]=aux;
      }
    }
  }
}

void BurbujaReves (int  *v, int n)
{
  int aux;
  for(int i=1;i<n;i++){
    for(int j=0;j<n-i;j++){
      if(v[j]<v[j+1]){
        aux=v[j+1];
        v[j+1]=v[j];
        v[j]=aux;
      }
    }
  }
}

void sintaxis()
{
  cerr << "Sintaxis:" << endl;
  cerr << "  TAM: Tamaño del vector (>0)" << endl;
  cerr << "  VMAX: Valor máximo (>0)" << endl;
  cerr << "Se genera un vector de tamaño TAM con elementos aleatorios en [0,VMAX[" << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char * argv[])
{
 if (argc!=3)
  sintaxis();
 int tam=atoi(argv[1]);
 int vmax=atoi(argv[2]);
 if (tam<=0 || vmax<=0)
  sintaxis();
/*
 int *v=new int[tam];

 srand(time(0));
 for (int i=0; i<tam; i++)
  v[i] = rand() % vmax;


 high_resolution_clock::time_point start, end;
 duration<double> tiempo_transcurrido;

 //MEJOR Y PEOR CASO
 Burbuja(v,tam); //EN EL MEJOR DE LOS CASOS PRIMERO ORDENAMOS Y LUEGO MEDIMOS
 BurbujaReves(v,tam); //EN EL PEOR DE LOS CASOS PRIMERO ORDENAMOS EL VECTOR AL REVES DE MAYOR A MENOR Y CALCULAMOS TIEMPO PARA ORDENARLO DE MENOR A MAYOR

 start = high_resolution_clock::now();
 Burbuja(v,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido  = duration_cast<duration<double> >(end - start);

 cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

 delete [] v;
 */

 //CASO PROMEDIO TIRAMOS EL ALGORITMO 3 VECES Y SUMAMOS TIEMPOS
 //PARA CALCULAR ORDEN PROMEDIO GENERAMOS 3 VECTORES EJECUTAMOS EL ALGORITMO PARA CADA UNO
 //GUARDAMOS TIEMPOS LOS SUMAMOS Y LO DIVIDIMOS ENTRE 3 Y SERÁ EL TIEMPO PROMEDIO
 int *v1=new int[tam];
 int *v2=new int[tam];
 int *v3=new int[tam];

 srand(time(0));
 for (int i=0; i<tam; i++){
  v1[i] = rand() % vmax;
  v2[i] = rand() % vmax;
  v3[i] = rand() % vmax;
 }

 high_resolution_clock::time_point start, end;
 duration<double> tiempo_transcurrido;

 start = high_resolution_clock::now();
 Burbuja(v1,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = duration_cast<duration<double> >(end - start);

 start = high_resolution_clock::now();
 Burbuja(v2,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = tiempo_transcurrido + duration_cast<duration<double> >(end - start);

 start = high_resolution_clock::now();
 Burbuja(v3,tam);
 end = high_resolution_clock::now();

 tiempo_transcurrido = tiempo_transcurrido + duration_cast<duration<double> >(end - start);
 tiempo_transcurrido = tiempo_transcurrido / 3;

 cout << tam << "\t" <<tiempo_transcurrido.count() << endl;

 delete [] v1;
 delete [] v2;
 delete [] v3;
 
}
