#!/bin/csh
@ inicio = 100
@ fin = 5000
@ incremento = 100
@ i = $inicio
echo > tiempos.dat
while ( $i <= $fin )
 echo Ejecución tam = $i
 echo `./mergesortAPO $i` >> tiempos.dat
 @ i += $incremento
end
