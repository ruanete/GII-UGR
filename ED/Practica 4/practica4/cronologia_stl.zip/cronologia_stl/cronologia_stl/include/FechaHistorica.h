#ifndef _FECHAHISTORICA_H_
#define _FECHAHISTORICA_H_

#include <iostream>
#include <cassert>
#include <string>
#include <set>

using namespace std;

class FechaHistorica {
  private:
    pair< int,set<string> > fechahistorica;

    typedef typename set<string>::iterator iterator;
    typedef typename set<string>::const_iterator const_iterator;

  public:
    //Iteradores//
    class Iterator {
      private:
        iterator it;
      public:
        friend class FechaHistorica;

        Iterator(){
          ;
        }

        Iterator(const Iterator & i){
          it = i.it;
        }

        Iterator& operator++(){
          ++it;
          return *this;
        }

        Iterator operator++(int){
          Iterator temp;
          temp.it = it;
          ++it;
          return temp;
        }

        Iterator& operator--(){
          --it;
          return *this;
        }

        Iterator operator--(int){
          Iterator temp;
          temp.it = it;
          --it;
          return temp;
        }

        const string &operator * () const{
          return *it;
        }

        bool operator ==(const Iterator &i){
          return i.it==it;
        }

        bool operator !=(const Iterator &i){
          return i.it!=it;
        }
    };

    Iterator begin(){
      Iterator i;
      i.it = fechahistorica.second.begin();
      return i;
    }

    Iterator end(){
      Iterator i;
      i.it = fechahistorica.second.end();
      return i;
    }

    class Const_Iterator {
      private:
        const_iterator it;
      public:
        friend class FechaHistorica;

        Const_Iterator(){
          ;
        }

        Const_Iterator(const Const_Iterator & i){
          it = i.it;
        }

        Const_Iterator& operator++(){
          ++it;
          return *this;
        }

        Const_Iterator operator++(int){
          Const_Iterator temp;
          temp.it = it;
          ++it;
          return temp;
        }

        Const_Iterator& operator--(){
          --it;
          return *this;
        }

        Const_Iterator operator--(int){
          Const_Iterator temp;
          temp.it = it;
          --it;
          return temp;
        }

        const string &operator * () const{
          return *it;
        }

        bool operator ==(const Const_Iterator &i){
          return i.it==it;
        }

        bool operator !=(const Const_Iterator &i){
          return i.it!=it;
        }
    };

    Const_Iterator begin() const{
      Const_Iterator i;
      i.it = fechahistorica.second.begin();
      return i;
    }

    Const_Iterator end() const{
      Const_Iterator i;
      i.it = fechahistorica.second.end();
      return i;
    }
    //Fin iteradores//

    FechaHistorica();
    FechaHistorica(int f, set<string> fh);
    FechaHistorica(const FechaHistorica& fh);
    ~FechaHistorica();
    int getAnio();
    string getHecho(int i);
    void setAnio(int a);
    void aniadirHechos(string& event);
    bool buscarHechos(string s, FechaHistorica& matches);
    FechaHistorica& operator= (const FechaHistorica& original);
    friend ostream& operator<< (ostream& os, const FechaHistorica& e);
    friend istream& operator>> (istream& is, FechaHistorica& e);
};

#endif
