#ifndef _CRONOLOGIA_H_
#define _CRONOLOGIA_H_

#include <iostream>
#include <cassert>
#include <string>
#include <map>
#include "FechaHistorica.h"

using namespace std;

class Cronologia {
  private:
    map<int,FechaHistorica> cronologia;

    typedef typename map<int,FechaHistorica>::iterator iterator;
    typedef typename map<int,FechaHistorica>::const_iterator const_iterator;

    void ordenar();
  public:
    //Iteradores//
    class Iterator {
      private:
        iterator it;
      public:
        friend class Cronologia;

        Iterator(){
          ;
        }

        Iterator(const Iterator & i){
          it = i.it;
        }

        Iterator& operator++(){
          ++it;
          return *this;
        }

        Iterator operator++(int){
          Iterator temp;
          temp.it = it;
          ++it;
          return temp;
        }

        Iterator& operator--(){
          --it;
          return *this;
        }

        Iterator operator--(int){
          Iterator temp;
          temp.it = it;
          --it;
          return temp;
        }

        const FechaHistorica& operator * () const{
          return it->second;
        }

        bool operator ==(const Iterator &i){
          return i.it==it;
        }

        bool operator !=(const Iterator &i){
          return i.it!=it;
        }
    };

    Iterator begin(){
      Iterator i;
      i.it = cronologia.begin();
      return i;
    }

    Iterator end(){
      Iterator i;
      i.it = cronologia.end();
      return i;
    }

    class Const_Iterator {
      private:
        const_iterator it;
      public:
        friend class Cronologia;

        Const_Iterator(){
          ;
        }

        Const_Iterator(const Const_Iterator & i){
          it = i.it;
        }

        Const_Iterator& operator++(){
          ++it;
          return *this;
        }

        Const_Iterator operator++(int){
          Const_Iterator temp;
          temp.it = it;
          ++it;
          return temp;
        }

        Const_Iterator& operator--(){
          --it;
          return *this;
        }

        Const_Iterator operator--(int){
          Const_Iterator temp;
          temp.it = it;
          --it;
          return temp;
        }

        const FechaHistorica& operator * () const{
          return it->second;
        }

        bool operator ==(const Const_Iterator &i){
          return i.it==it;
        }

        bool operator !=(const Const_Iterator &i){
          return i.it!=it;
        }
    };

    Const_Iterator begin() const{
      Const_Iterator i;
      i.it = cronologia.begin();
      return i;
    }

    Const_Iterator end() const{
      Const_Iterator i;
      i.it = cronologia.end();
      return i;
    }
    //Fin iteradores//

    Cronologia();
    Cronologia(int f, FechaHistorica fh);
    Cronologia(const Cronologia& c);
    ~Cronologia();
    int size() const;
    void aniadirEvento(FechaHistorica& f);
    //int buscarAnio(int f);
    Cronologia buscarEventos(string s);
    //Cronologia eventosPalabra(string palabra);
    //Cronologia eventosFechas(int inicio,int final);
    //Cronologia eventosAnio(int fecha);
    FechaHistorica getHecho(int i);
    Cronologia& operator= (const Cronologia& original);
    Cronologia operator+ (const Cronologia& original);
    friend ostream& operator<< (ostream& os, const Cronologia& e);
    friend istream& operator>> (istream& is, Cronologia& e);
};

#endif
