#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <set>
#include "FechaHistorica.h"

using namespace std;

FechaHistorica::FechaHistorica(){
  fechahistorica.first = 0;
}

FechaHistorica::FechaHistorica(int f, set<string> fh){
  assert(f>=0 && f<=9999);
  fechahistorica.first = f;
  fechahistorica.second = fh;

  /*set<string>::iterator it;
  for(it=fh.begin();it<fh.end();it++)
    fechahistorica.second.insert(*it, it);*/
}

FechaHistorica::FechaHistorica(const FechaHistorica& fh){
  fechahistorica.first = fh.fechahistorica.first;
  fechahistorica.second = fh.fechahistorica.second;
}

FechaHistorica::~FechaHistorica(){
  ;
}

int FechaHistorica::getAnio(){
  return fechahistorica.first;
}

string FechaHistorica::getHecho(int i){
  //assert(i>=0 && i<=fechahistorica.second.size());

  int contador=0;
  set<string>::iterator it;
  it=fechahistorica.second.begin();

  while(contador!=i){
    it++;
    contador++;
  }

  return *it;
}

void FechaHistorica::setAnio(int a){
  fechahistorica.first = a;
}

void FechaHistorica::aniadirHechos(string& hecho){
  fechahistorica.second.insert(hecho);
}

bool FechaHistorica::buscarHechos(string s, FechaHistorica& matches){
  bool encontrado=false;
  set<string>::iterator it;

  it = fechahistorica.second.find(s);

  if(it != fechahistorica.second.end()){
    encontrado = true;
    matches.fechahistorica.first = fechahistorica.first;
    fechahistorica.second.insert(*it);
  }

  return encontrado;
}

FechaHistorica& FechaHistorica::operator= (const FechaHistorica& original){
  if(this!=&original){
    fechahistorica.first = original.fechahistorica.first;
    fechahistorica.second = original.fechahistorica.second;
  }
  return *this;
}

ostream& operator<< (ostream& os, const FechaHistorica& e){
  set<string>::iterator it;

  os << e.fechahistorica.first;
  for(it=e.fechahistorica.second.begin();it!=e.fechahistorica.second.end();++it)
    os << "#" << *it;
  return os;
}

istream& operator>> (istream& is, FechaHistorica& e){
  string linea, linea_aux, year;
  int i=0;

  getline(is,linea);

  year = linea;
  e.fechahistorica.first = atoi(year.erase(4).c_str());
  linea.erase(0,5);

  while((linea.find("#")) != string::npos){
    linea_aux = linea.substr(0,linea.find('#'));
    e.fechahistorica.second.insert(linea_aux);
    linea.erase(0,linea.find('#')+1);
    i++;
  }

  e.fechahistorica.second.insert(linea);

  return is;
}
