#include <iostream>
#include <sstream>
#include <cstring>
#include <map>
#include "Cronologia.h"

using namespace std;

//Iteradores//

//Fin iteradores//

Cronologia::Cronologia(){
  ;
}

Cronologia::Cronologia(int f, FechaHistorica fh){
  pair<int,FechaHistorica> c;
  c.first = f;
  c.second = fh;
  cronologia.insert(c);
}

Cronologia::Cronologia(const Cronologia& c){
  cronologia = c.cronologia;
}

Cronologia::~Cronologia(){
  ;
}

int Cronologia::size() const{
  return cronologia.size();
}

void Cronologia::aniadirEvento(FechaHistorica& f){
  pair<int,FechaHistorica> c;
  c.first = f.getAnio();
  c.second = f;
  cronologia.insert(c);
  //ordenar();
}

/*
PD:Cuando hago un find me devuelve el valor del map entero es decir un pair de int,FechaHistorica
luego no puedo devolver la posicion que tiene en el map

int Cronologia::buscarAnio(int f){
  int i=0;
  bool valido=false;
  map<int,FechaHistorica>::iterator it;

  if(cronologia.find(f)!=cronologia.end()){
    valido = true;
    it=cronologia.find(f)->first;
    i = *it;
  }

  if(!valido)
     i=-1;

  return i;
}
*/

Cronologia Cronologia::buscarEventos(string s){
  Cronologia nuevo;
  map<int,FechaHistorica>::iterator it;

  for(it=cronologia.begin();it!=cronologia.end();it++){
    FechaHistorica aux;
    if(it->second.buscarHechos(s,aux))
      nuevo.aniadirEvento(aux);
  }
  //nuevo.ordenar();
  return nuevo;
}

FechaHistorica Cronologia::getHecho(int i){
  return cronologia[i];
}

Cronologia& Cronologia::operator= (const Cronologia& original){
  if(this!=&original){
    map<int,FechaHistorica>::const_iterator it;
    cronologia.clear();
    for(it=original.cronologia.begin();it!=original.cronologia.end();it++){
      pair<int,FechaHistorica> c;
      c.first = it->first;
      c.second = it->second;
      cronologia.insert(c);
    }
  }
  return *this;
}

ostream& operator<< (ostream& os, const Cronologia& c){
  map<int,FechaHistorica>::const_iterator it;
  for(it=c.cronologia.begin();it!=c.cronologia.end();it++)
    os << it->second << endl;

  return os;
}

istream& operator>> (istream& is, Cronologia& c){
  string linea;

  while(!is.eof()){
    getline(is,linea,'\n');

    if((strcmp(linea.c_str(),""))!=0){
      FechaHistorica fecha;
      stringstream ss(linea);
      ss >> fecha;
      c.aniadirEvento(fecha);
    }
  }

  return is;
}
